# Try-Django
Learn Django bit by bit in this series.
